read input
./fd $input